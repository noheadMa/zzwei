/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50729
 Source Host           : localhost:3306
 Source Schema         : warehouse

 Target Server Type    : MySQL
 Target Server Version : 50729
 File Encoding         : 65001

 Date: 28/06/2023 05:09:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bill
-- ----------------------------
DROP TABLE IF EXISTS `bill`;
CREATE TABLE `bill`  (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `productName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `totalPrice` double(10, 2) NOT NULL,
  `shopId` int(12) NOT NULL,
  `shopName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `amount` double(255, 0) NOT NULL,
  `specs` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `time` datetime(0) NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bill
-- ----------------------------
INSERT INTO `bill` VALUES (1, 'apple', 250.00, 1, '杂货铺', 50, '斤', '出库', '2023-06-28 04:39:12');
INSERT INTO `bill` VALUES (2, 'apple', 50.00, 1, '杂货铺', 40, '斤', '出库', '2023-06-28 04:50:31');
INSERT INTO `bill` VALUES (3, '香蕉', 150.00, 1, '杂货铺', 0, '斤', '出库', '2023-06-28 04:50:35');
INSERT INTO `bill` VALUES (4, 'apple', 50.00, 1, '杂货铺', 50, '斤', '入库', '2023-06-28 04:51:46');
INSERT INTO `bill` VALUES (5, '香蕉', 150.00, 1, '杂货铺', 10, '斤', '入库', '2023-06-28 04:52:05');
INSERT INTO `bill` VALUES (6, '香蕉', 150.00, 1, '杂货铺', 20, '斤', '入库', '2023-06-28 04:52:33');
INSERT INTO `bill` VALUES (7, '香蕉', 150.00, 1, '杂货铺', 30, '斤', '入库', '2023-06-28 04:52:33');
INSERT INTO `bill` VALUES (8, 'apple', 50.00, 1, '杂货铺', 40, '斤', '出库', '2023-06-28 04:53:30');
INSERT INTO `bill` VALUES (9, 'apple', 50.00, 1, '杂货铺', 30, '斤', '出库', '2023-06-28 04:53:30');
INSERT INTO `bill` VALUES (10, 'apple', 50.00, 1, '杂货铺', 20, '斤', '出库', '2023-06-28 04:53:30');
INSERT INTO `bill` VALUES (11, 'apple', 50.00, 1, '杂货铺', 10, '斤', '出库', '2023-06-28 04:53:31');
INSERT INTO `bill` VALUES (12, 'apple', 50.00, 1, '杂货铺', 0, '斤', '出库', '2023-06-28 04:53:31');

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '商品编号',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '商品名称',
  `price` double(10, 2) NOT NULL COMMENT '商品价格',
  `specs` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shopId` int(10) NOT NULL,
  `shopName` varchar(255) CHARACTER SET gb2312 COLLATE gb2312_chinese_ci NOT NULL,
  `amount` double(12, 0) NOT NULL COMMENT '商品价格',
  `time` datetime(6) NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (1, '香蕉', 15.00, '斤', 1, '杂货铺', 30, '2023-06-28 00:56:24.000000');
INSERT INTO `product` VALUES (2, 'apple', 5.00, '斤', 1, '杂货铺', 0, '2023-06-28 00:56:56.000000');

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES (1, '杂货铺');
INSERT INTO `shop` VALUES (2, '美宜佳');
INSERT INTO `shop` VALUES (3, 'Today');
INSERT INTO `shop` VALUES (4, '7天');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '123', '123');

SET FOREIGN_KEY_CHECKS = 1;
